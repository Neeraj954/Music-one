package com.dn0ne.player.app.presentation.components.trackinfo

data class ManualInfoEditSheetState(
    val pickedCoverArtBytes: ByteArray? = null
)
