package com.dn0ne.player.app.domain.result

sealed interface Error