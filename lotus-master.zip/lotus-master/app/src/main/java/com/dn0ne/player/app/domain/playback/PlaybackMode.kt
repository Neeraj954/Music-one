package com.dn0ne.player.app.domain.playback

enum class PlaybackMode {
    Repeat,
    RepeatOne,
    Shuffle
}