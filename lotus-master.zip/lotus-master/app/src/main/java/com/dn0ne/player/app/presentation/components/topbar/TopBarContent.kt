package com.dn0ne.player.app.presentation.components.topbar

enum class TopBarContent {
    Default, Search, Selection
}